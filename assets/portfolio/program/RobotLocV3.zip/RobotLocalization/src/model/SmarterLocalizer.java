package model;

import java.util.ArrayList;
import java.util.List;

import control.EstimatorInterface;

public class SmarterLocalizer implements EstimatorInterface {
	
private int rows, cols, head;
private int trueX, trueY, trueH;
private int[] sensorPos = {-1,-1};


private Double[][] observations;
private Double[][][] transitions;
private Double[][] currentProb;

public SmarterLocalizer( int rows, int cols, int head, int[] startState) {
	this.rows = rows;
	this.cols = cols;
	this.head = head;
	
	if (startState == null) {
		this.trueX = (int) (Math.random()*this.rows);
		this.trueY = (int) (Math.random()*this.cols);
		this.trueH = (int) (Math.random()*this.head);
	}
	else {
		this.trueX = startState[0];
		this.trueY = startState[1];
		this.trueH = startState[2];
	}
	
	//set Observation
	this.observations = new Double[this.rows*this.cols+1][this.rows*this.cols];
	int[][] numberSuroundings = new int[this.rows*this.cols][2];
	for (int t_x =0 ; t_x < this.rows ; t_x++) {
		for (int t_y=0 ; t_y < this.cols ; t_y++) {
			for (int i =0 ; i < this.rows ; i++) {
				for (int j=0 ; j < this.cols ; j++) {
					
					if (i==t_x && j== t_y) {
						observations[t_x*this.cols+t_y][i*this.cols+j] = 0.1;
					}
					else if ((t_x-i)*(t_x-i) + (t_y-j)*(t_y-j) < 4) {
						observations[t_x*this.cols+t_y][i*this.cols+j] = 0.05;
						numberSuroundings[t_x*this.cols+t_y][0]++;
					}
					else if ((t_x-i)*(t_x-i) + (t_y-j)*(t_y-j) < 9) {
						observations[t_x*this.cols+t_y][i*this.cols+j] = 0.025;
						numberSuroundings[t_x*this.cols+t_y][1]++;
					}
					else {
						observations[t_x*this.cols+t_y][i*this.cols+j] = 0.;
					}
				}
			}
		}
	}
	for (int i =0 ; i < this.rows ; i++) {
		for (int j=0 ; j < this.cols ; j++) {
			int n_Ls = numberSuroundings[i*this.cols+j][0];
			int n_Ls2 = numberSuroundings[i*this.cols+j][1];
			observations[this.rows*this.cols][i*this.cols+j] = 1 - (0.1 + 0.05*n_Ls + 0.025*n_Ls2); 
		}
	}
	
	// set transitions
	this.transitions = new Double[this.rows*this.cols][this.rows*this.cols][this.head+1];
	for (int t_x =0 ; t_x < this.rows ; t_x++) {
		for (int t_y=0 ; t_y < this.cols ; t_y++) {
			for (int i =0 ; i < this.rows ; i++) {
				for (int j=0 ; j < this.cols ; j++) {
					if ((t_x-i)*(t_x-i) + (t_y-j)*(t_y-j) == 1) {
						double direction = this.vectorToDirection(i - t_x , j - t_y);
						this.transitions[t_x*this.cols + t_y][i*this.cols + j][this.head] = direction;
						for (int h = 0; h<this.head; h++ ) {
							this.transitions[t_x*this.cols + t_y][i*this.cols + j][h] = this.getCellProb(t_x , t_y , h);
						}
						double interm = this.transitions[t_x*this.cols + t_y][i*this.cols + j][(int) direction];
						if (interm > 1) interm = 1.0;
						this.transitions[t_x*this.cols + t_y][i*this.cols + j][(int) direction] = Math.max(0.7, interm);
					}
					else {
						this.transitions[t_x*this.cols + t_y][i*this.cols + j] = null;
					}
					
				}
			}
		}
	}
	
	//set currentProbs
	this.currentProb = new Double[this.rows][this.cols];
	for (int x = 0; x<this.rows; x++) {
		for (int y = 0; y<this.cols; y++) {
			this.currentProb[x][y] = 1.0 / (this.cols*this.rows);
		}
	}
}	

public int getNumRows() {
	return rows;
}

public int getNumCols() {
	return cols;
}

public int getNumHead() {
	return head;
}

public double getTProb( int x, int y, int h, int nX, int nY, int nH) {
	if (this.transitions[x*this.cols+y][nX*this.cols+nY] == null) {
		return 0.0;
	}
	if (nH == this.transitions[x*this.cols+y][nX*this.cols+nY][this.head]) {
		return this.transitions[x*this.cols+y][nX*this.cols+nY][h];
	}
	else {
		return 0.0;
	}
}

public double getOrXY( int rX, int rY, int x, int y, int h) {
	if (rX == -1 || rY == -1) {
		return this.observations[this.rows*this.cols][x*this.cols+y];
	}
	else {
		return this.observations[rX*this.cols+rY][x*this.cols+y];
	}
}

public int[] getCurrentTrueState() {
	int[] ret = new int[3];
	ret[0] = this.trueX;
	ret[1] = this.trueY;
	ret[2] = this.trueH;
	return ret;
}

public int[] getCurrentReading() {
	if (this.sensorPos[0]==-1) {
		return null;
	}
	else {
		return this.sensorPos;
	}
}


public double getCurrentProb( int x, int y) {
	return this.currentProb[x][y];
}

public void update() {
	this.updateTrueState();
	this.updateSensorPos();
	this.updateCurrentProbs();
	
	
//	String str = "";
//	for (int x = 0; x<this.rows; x++) {
//		for (int y = 0; y<this.cols; y++) {
//			str += "\t" + this.globalCount[x][y];
//		}
//		str+= "\n";
//	}
//	System.out.println(str);
	
//	System.out.println("The current state is x = "+this.trueX+" , y = "+this.trueY+" , h = "+this.trueH);
}

public double getDistance(int mode) {
	double max = Double.MIN_VALUE;
	int PredictedX = 0;
	int PredictedY = 0;
	int probaDist = 0;
	for (int x=0; x<this.rows; x++) {
		for (int y=0; y<this.cols; y++) {
			if (max < this.getCurrentProb(x, y)) {
				max = this.getCurrentProb(x, y);
				PredictedX = x;
				PredictedY = y;
			}
			if (this.getCurrentProb(trueX, trueY) < this.getCurrentProb(x, y)) {
				probaDist ++;
			}
		}
	}
	if(mode == 0) {
		return Math.sqrt( (this.trueX - PredictedX)*(this.trueX - PredictedX) + (this.trueY - PredictedY)*(this.trueY - PredictedY));
	}
	else if (mode == 1) {
		return Math.abs(this.trueX - PredictedX) + Math.abs(this.trueY - PredictedY);
	}
	else if (mode == 2) {
		return probaDist;
	}
	else {
		return 0;
	}
	}

/***********************************************************************************************
 * UPDATE TRUE STATE
 ***********************************************************************************************/

public int bound(int num, int limit) {
	if (num < 0) {
		return 0;
	}
	else if (num >= limit) {
		return limit - 1;
	}
	else {
		return num;
	}
}

public int[] getNewPosition(int x, int y, int header) {
	int[] ret = new int[2];
	if (header == 0) {
		ret[0] = this.bound(x - 1, this.rows);
		ret[1] = y;
	}
	else if (header == 1) {
		ret[0] = x;
		ret[1] = this.bound(y + 1, this.cols);
	}
	else if (header == 2) {
		ret[0] = this.bound(x + 1, this.rows);
		ret[1] = y;
	}
	else if (header == 3) {
		ret[0] = x;
		ret[1] = this.bound(y - 1, this.cols); 
	}
	else {
		ret = null;
		System.out.println("header is out of range !");
	}
	return ret;
}

public void updateTrueState() {
	
	List<Integer> allowedH = new ArrayList<Integer>();
	allowedH.add(0);allowedH.add(1);allowedH.add(2);allowedH.add(3);
	boolean noWall = true;
	
	if (this.trueX == 0) {
		allowedH.remove(allowedH.indexOf(0));
		if (this.trueH == 0) noWall = false;
	}
	if (this.trueY == this.cols - 1) {
		allowedH.remove(allowedH.indexOf(1));
		if (this.trueH == 1) noWall = false;
	}
	if (this.trueX == this.rows - 1) {
		allowedH.remove(allowedH.indexOf(2));
		if (this.trueH == 2) noWall = false;
	}
	if (this.trueY == 0) {
		allowedH.remove(allowedH.indexOf(3));
		if (this.trueH == 3) noWall = false;
	}
	
	for (int i= 0; i < allowedH.size() ; i++) {
//		System.out.println(allowedH.get(i));
	}
	
	if (noWall) {
		double randomHeading = Math.random();
		if (randomHeading < 0.3) {
			int randomIndexH = (int) (Math.random()*(allowedH.size()));
//			System.out.println("randomIndexH = " +randomIndexH);
			this.trueH = allowedH.get(randomIndexH);
		}
	}
	else {
		int randomIndexH = (int) (Math.random()*(allowedH.size()));
//		System.out.println("randomIndexH = " +randomIndexH);
		this.trueH = allowedH.get(randomIndexH);
	}
	
	int[] pos = getNewPosition(this.trueX, this.trueY, this.trueH);
	this.trueX = pos[0];
	this.trueY = pos[1];
}

/***********************************************************************************************
 * UPDATE SENSOR
 ***********************************************************************************************/

public ArrayList<Coordinate> getSuroundings1(int x, int y){
	ArrayList<Coordinate> surounding1 = new ArrayList<Coordinate>();
	for (int i=-1 ; i<2 ; i++) {
		for (int j=-1; j<2 ; j++) {
			if ((j !=0 && i !=0) && (x+i >= 0 && y+j >= 0) && (x+i < this.rows && y+j < this.cols)) {
				surounding1.add(new Coordinate(x+i , y+j));
			}
		}
	}
	return surounding1;
}

public ArrayList<Coordinate> getSuroundings2(int x, int y){
	ArrayList<Coordinate> surounding2 = new ArrayList<Coordinate>();
	for (int i=-2 ; i<3 ; i++) {
		for (int j=-2; j<3 ; j++) {
			if ((i*i + j*j >= 4) && (x+i >= 0 && y+j >= 0) && (x+i < this.rows && y+j < this.cols)) {
				surounding2.add(new Coordinate(x+i , y+j));
			}
		}
	}
	return surounding2;
}

public void updateSensorPos() {
	ArrayList<Coordinate> Ls = getSuroundings1(this.trueX, this.trueY);
	ArrayList<Coordinate> Ls2 = getSuroundings2(this.trueX, this.trueY);
	int n_Ls = Ls.size();
	int n_Ls2 = Ls2.size();
	
	double proba_L = 0.1;
	double proba_Ls = 0.05;
	double proba_Ls2 = 0.025;
	double random = Math.random();
	
	if (random < proba_L) {
		this.sensorPos[0] = this.trueX;
		this.sensorPos[1] = this.trueY;
	}
	else if (random < proba_L + n_Ls*proba_Ls) {
		int randomIndex = (int) ( Math.random()*(n_Ls));
		this.sensorPos[0] = Ls.get(randomIndex).getX();
		this.sensorPos[1] = Ls.get(randomIndex).getY();
	}
	else if (random < proba_L + n_Ls*proba_Ls + n_Ls2*proba_Ls2) {
		int randomIndex = (int) (Math.random()*(n_Ls2));
		this.sensorPos[0] = Ls2.get(randomIndex).getX();
		this.sensorPos[1] = Ls2.get(randomIndex).getY();
	}
	else {
		this.sensorPos[0] = -1;
		this.sensorPos[1] = -1;
	}
}

/***********************************************************************************************
 * UPDATE CURRENT PROBS
 ***********************************************************************************************/
public void updateCurrentProbs() {
	Double[][] newProb = new Double[this.rows][this.cols];
	
	double alpha = 0.0;
	for (int x=0; x<this.rows; x++) {
		for (int y=0; y<this.cols; y++) {
			
			double probaSum = 0;
			for (int h=0; h<this.head; h++) {
				for (int xOld=0; xOld<this.rows; xOld++) {
					for (int yOld=0; yOld<this.cols; yOld++) {
						for (int hOld=0; hOld<this.head; hOld++) {
							probaSum += this.getTProb(xOld, yOld, hOld, x, y, h)*this.currentProb[xOld][yOld];
						}
					}
				}
			}
			
			newProb[x][y] = this.getOrXY(this.sensorPos[0], this.sensorPos[1], x, y, 0) * probaSum;
			alpha += newProb[x][y];
		}
	}
	alpha = 1.0/alpha;
	for (int x=0; x<this.rows; x++) {
		for (int y=0; y<this.cols; y++) {
			newProb[x][y]= alpha * newProb[x][y];
		}
	}
	this.currentProb = newProb;
}


/***********************************************************************************************
 * SETTING THE TRANSITION MATRIX
 ***********************************************************************************************/

public double vectorToDirection(int xVect, int yVect) {
	if (xVect == -1 && yVect == 0) {
		return 0.;
	}
	else if (xVect == 0 && yVect == 1) {
		return 1.;
	}
	else if (xVect == 1 && yVect == 0) {
		return 2.;
	}
	else if (xVect == 0 && yVect == -1) {
		return 3.;
	}
	else {
		System.out.println("Vector can't be read");
		return -1.;
	}
}

public double getCellProb(int x, int y, int h) {
	ArrayList<Integer> directionToWall = new ArrayList<Integer>();
	if (x == 0) {
		directionToWall.add(0);
	}
	if (y == this.cols-1) {
		directionToWall.add(1);
	}
	if (x == this.rows-1) {
		directionToWall.add(2);
	}
	if (y == 0) {
		directionToWall.add(3);
	}
	if (directionToWall.contains(h)) {
		return 1./(this.head -directionToWall.size());
	}
	else {
		return 0.3/(this.head -1 -directionToWall.size()) ;
	}
}

}