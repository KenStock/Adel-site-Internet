package model;

public class Coordinate {
	private int x;
	private int y;
	
	public Coordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Coordinate(int[] list) {
		if (list == null) {
			this.x = -1;
			this.y = -1;
		}
		else {
			this.x = list[0];
			this.y = list[1];
		}
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
}
