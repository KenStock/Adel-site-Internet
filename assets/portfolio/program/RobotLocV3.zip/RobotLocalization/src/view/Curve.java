package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Curve extends JPanel{
	private String name;
	private ArrayList<Double> valueY = new ArrayList<Double>();
	private ArrayList<Double> valueX = new ArrayList<Double>();
	private double spaceBellow;
	private int marginX;
	private int marginY;
	
	public Curve(String name) {
		this.name = name;
		this.spaceBellow = 40;
		this.marginX = 25;
		this.marginY = 25;
	}
	
	public void paint (Graphics g) {
	    Graphics2D g2 = (Graphics2D) g;
 
		int numberOfPoint= valueY.size();
		double maxNumX = this.max(valueX);
		double maxNumY = this.max(valueY);
		
		int sizeX = this.getWidth() - 2*marginX;
		int sizeY = (int) (this.getHeight() - 2*marginY - this.spaceBellow);
		
		g2.setColor(Color.blue);
		for (int i = 1; i < numberOfPoint; i++) {
 
			Double x1 = marginX + (i-1)*(sizeX)/maxNumX;
			Double x2 = marginX + (i)*(sizeX)/maxNumX;
			
			Double y1 = marginY + sizeY - this.valueY.get(i-1)*(sizeY)/maxNumY;
			Double y2 = marginY + sizeY - this.valueY.get(i)*(sizeY)/maxNumY;
 	
			g2.draw(new Line2D.Double(x1, y1, x2, y2));
		}
		
		g2.setColor(Color.red);
		int interp = (this.valueX.size()/10) - ((this.valueX.size()/10) % 3)/3;
		if (interp%2 == 0) interp--;
		if (interp >= 3) {
			for (int i = (interp-1)/2 +1; i < numberOfPoint-(interp-1)/2; i++) {
				 
				Double x1 = marginX + (i-1)*(sizeX)/maxNumX;
				Double x2 = marginX + (i)*(sizeX)/maxNumX;
				
				double sum = 0.0;
				for (int j=-(interp-1)/2; j<=(interp-1)/2-1; j++) {
					sum += this.valueY.get(i+j);
				}
				
				Double y1 = marginY + sizeY - (( this.valueY.get(i-(interp-1)/2-1) + sum)/((double) interp))*(sizeY)/maxNumY;
				Double y2 = marginY + sizeY - (( sum + this.valueY.get(i+(interp-1)/2))/((double) interp))*(sizeY)/maxNumY;
	 	
				g2.draw(new Line2D.Double(x1, y1, x2, y2));
			}
		}
		
		g2.setColor(Color.BLACK);
		
		g2.draw(new Line2D.Double(marginX, marginY, marginX, sizeY + marginY));
		g2.draw(new Line2D.Double(marginX, marginY, marginX-5, marginY+10));
		g2.draw(new Line2D.Double(marginX, sizeY + marginY, sizeX + marginX, sizeY + marginY));
		g2.draw(new Line2D.Double(sizeX + marginX, sizeY + marginY, marginX + sizeX - 10, marginY + sizeY + 5));
		
		int digit = (int) Math.pow(10, (int) (Math.log10(maxNumX)));
		for (int iX=0; iX<maxNumX ; iX++) {
			if (digit != 0 && ((iX % digit) == 0)) {
				g2.drawString(""+iX, (int) (marginX + iX*sizeX/maxNumX), 3*marginY/2+sizeY);
				g2.draw(new Line2D.Double((int) (marginX + iX*sizeX/maxNumX), marginY+sizeY, (int) (marginX + iX*sizeX/maxNumX), marginY+sizeY + 5));
			}
		}
		
		int digitY = (int) Math.pow(10, (int) (Math.log10(maxNumY)));
		for (int iY=0; iY< maxNumY; iY++) {
			if (digitY != 0 && ((iY % digitY) == 0)) {
				g2.drawString(""+iY, (int) (marginX/2), (int) (marginY + sizeY*(1 - iY/maxNumY)));
				g2.draw(new Line2D.Double(marginX, (int) (marginY + sizeY*(1 - iY/maxNumY)), marginX - 5, (int) (marginY + sizeY*(1 - iY/maxNumY)) ));
			}
		}
		
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 20.0f));
		g2.drawString(this.name + "  Moy= " + this.getMoy(), 3*marginX, sizeY + 2*marginY);
		g2.drawString("  Success= " + this.getSuccessPerc() + "%", 5*marginX, sizeY + 3*marginY);
		
	}
	
	public Double max(ArrayList<Double> value) {
		Double max = Double.MIN_VALUE;
		for (int i=0 ; i<value.size() ; i++) {
			if (value.get(i) > max) {
				max = value.get(i);
			}
		}
		return max;
	}
	
	public void addPoint(double y) {
		this.valueY.add(y);
		if (valueX.isEmpty()) {
			valueX.add(0.0);
		}
		else {
			valueX.add(valueX.get(valueX.size()-1) + 1);
		}
	}
	
	public double getMoy() {
		double sum = 0;
		for (int i=0; i<this.valueY.size(); i++) {
			sum += this.valueY.get(i);
		}
		Double moy =sum/this.valueY.size();
		String s = moy.toString();
		return Double.valueOf(s.substring(0, Math.min(s.length(), 4)));
	}
	
	public double getSuccessPerc() {
		double sum = 0;
		for (int i=0; i<this.valueY.size(); i++) {
			if(this.valueY.get(i)==0) {
				sum ++;
			}
		}
		Double pers = (sum/this.valueY.size()) *100;
		String s = pers.toString();
		return Double.valueOf(s.substring(0, Math.min(s.length(), 4)));
	}
}
