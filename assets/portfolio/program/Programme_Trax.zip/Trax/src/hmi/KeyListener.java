package hmi;

public interface KeyListener {

}
