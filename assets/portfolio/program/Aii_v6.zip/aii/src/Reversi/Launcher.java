package Reversi;

import javax.swing.JOptionPane;

import control.GameController;
import hmi.GamePanel;
import hmi.GameWindow;
import hmi.Information;

public class Launcher {

	/*
	 * Welcome to the Reversi Game.
	 * 
	 * To launch the game, please Run Launcher.java onto eclipse. Then enter a game mode for each player. You can choose between:
	 * 		- 0 = human
	 * 		- 1 = random
	 * 		- 2 = MonteCarlo (with 20 tries)
	 * 		- 3 = min max algorithm (with a depth of 3 and the heuristic 1)
	 * 		- 4 = min max algorithm (with a depth of 2 and the heuristic 2)
	 * 		- 5 = min max alpha/beta algorithm (with a depth of 3 and the heuristic 1)
	 * 		- 6 = min max alpha/beta algorithm (with a depth of 2 and the heuristic 2) 
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JOptionPane jop = new JOptionPane(), jop2 = new JOptionPane();
	    String mode1 = jop.showInputDialog(null, "Please choose a game mode for player 1 (0=manual, 1=random, 2= MonteCarlo, 3= minMax, 5= minMax_AlphaBeta)", "Game mode", JOptionPane.QUESTION_MESSAGE);
	    while (Integer.parseInt(mode1) > 6 || Integer.parseInt(mode1) < 0) {
	    	mode1 = jop.showInputDialog(null, "Error, please choose a game mode for player  (0=manual, 1=random, 2= MonteCarlo, 3= minMax, 5= minMax_AlphaBeta)", "Error", JOptionPane.QUESTION_MESSAGE);
	    }
	    
	    String mode2 = jop.showInputDialog(null, "Please choose a game mode for player 2 (0=manual, 1=random, 2= MonteCarlo, 3= minMax, 5= minMax_AlphaBeta)", "Game mode", JOptionPane.QUESTION_MESSAGE);
	    while (Integer.parseInt(mode2) > 6 || Integer.parseInt(mode2) < 0) {
	    	mode2 = jop.showInputDialog(null, "Error, please choose a game mode for player  (0=manual, 1=random, 2= MonteCarlo, 3= minMax, 5= minMax_AlphaBeta)", "Error", JOptionPane.QUESTION_MESSAGE);
	    }
	    jop2.showMessageDialog(null, "Vous jouez " + mode1 + " contre " + mode2, "GameMode", JOptionPane.INFORMATION_MESSAGE);
		
		
		int[] mode = {Integer.parseInt(mode1),Integer.parseInt(mode2)};
		GameController ctrl = new GameController(mode);
		Information information = new Information(ctrl, 0);
		GamePanel p = new GamePanel(ctrl);
		new GameWindow(p,ctrl,information);
	}

}
