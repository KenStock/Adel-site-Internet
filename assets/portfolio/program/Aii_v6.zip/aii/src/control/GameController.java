package control;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import Game.Coordinate;
import Game.Engine;

public class GameController {
	
	/*
	 * loc: the next position we are going to play on
	 * playerColor: the color of the curent player (0= black; 1= white)
	 * mode: the game mode we are playing with (cf Launcher class)
	 * 
	 * timeInGame = time since the automatic player started to play
	 * timeLimite = time limitation. When timeInGame >= timeInGame --> play randomly
	 * 
	 */
	
	public Engine engine;
	public List<Integer> loc = new ArrayList<Integer>();
	public int playerColor;
	public int[] mode;
	public int gameTest;
	public int timeInGame;
	public int timeLimite = 1000;
	
	public int gameState; // 0 = starting screen; 1 = playing; 2 = gameover.
	public int winner; // Stays at -1 until the game ends: 0= the darks won; 1= the whites won; 2= there is a tie.
	
	public GameController(int[] gameMode) {
		this.engine = new Engine();
		this.playerColor = 0;
		this.gameTest = 0;
		this.timeInGame = 0;
		gameState = 0;
		winner = -1;
		this.mode = gameMode;
	}
	
	public int getHeight() {
		return this.engine.getHeight();
	}
	
	public int getWidth() {
		return this.engine.getWidth();
	}
	
	public int getCellColor(int x, int y) {
		return this.engine.getCellColor(x,y);
	}
	
	public int getCellPoints(int x, int y) {
		return this.engine.getCellPoints(x, y);
	}
	
	public int[] score() {
		return this.engine.score();
	}
	
	int indexMax(ArrayList<Integer> list) { 
		//gives the index of the maximal value among a list
	    int max = Integer.MIN_VALUE;
	    int max_i = 0;
	    for(int i=0; i<list.size(); i++){
	        if(list.get(i) > max){
	            max = list.get(i);
	            max_i = i;
	        }
	    }
	    return max_i;
	}
	
	/*****************************************************************************************
	 * JEU AL�ATOIRE
	 *****************************************************************************************/
	public void randomStep() {
		//picks a random coordinate among those possible
		ArrayList<int[]> list = engine.getPossibleMoves();
		int length = list.size();
		if (length>0) {
			int[] e = list.get((int) (Math.random()*length));
			loc.add(e[0]);
			loc.add(e[1]);
		}
	}
	
	/*****************************************************************************************
	 * JEU MONTE CARLO
	 *****************************************************************************************/

	public void nextMonteCarloStep(int nTry) {
		//Picks a coordinate among those possible according to the Monte Carlo alogo with nTry tries and a depth = 100.
		this.gameTest = 1;
		ArrayList<int[]> possibleLocation = engine.getPossibleMoves(); //list of the possible moves
		int playerColorTest = this.playerColor;
		int winnerOriginal = this.winner;
		
		ArrayList<Integer> scoreForEachMoves = new ArrayList<Integer>();
		
		for (int[] locTest : possibleLocation) { //test every coordinates
			int s_win = 0;
			for (int it = 0; it<nTry; it++) {
				Engine engineClone = (Engine) engine.clone(); //using a clone of the engine
				if (this.timeInGame >= this.timeLimite) { 
					System.out.println("Temps �coul� !!");
					break;
				}
				loc.add(locTest[0]); loc.add(locTest[1]);
				int w = winnerOriginal;
				w = this.placeLoc(engineClone, w);
				int depth = 100;
				int i =0;
				
				while((w==-1 && i <depth) && engineClone.isPossibleMove()) { //plays randomly onto the cloned board until the end of the game or 100 moves have been reached
					this.randomStep();
					w = this.placeLoc(engineClone, w);
					i++;
				}
				
				//the heuristic = if we won or have more disks on the board than the other player, the cell wins a point
				if (w==playerColorTest || (engineClone.score()[playerColorTest] > engineClone.score()[(playerColorTest+1)%2])) {
					s_win++;
				}
				
				s_win = engineClone.score()[playerColorTest];
			}
			scoreForEachMoves.add(s_win);
		}
		
		int maxId = indexMax(scoreForEachMoves);
		this.gameTest =0;
		loc.add(possibleLocation.get(maxId)[0]); loc.add(possibleLocation.get(maxId)[1]);
	}
	
	public int placeLoc(Engine engine, int winner) {
		//puts the disk onto the board of the engine and choose the next player accordingly
		engine.addDisk(new Coordinate(loc.get(0),loc.get(1)), engine.player);
		engine.resetLegalMoves();
		engine.player = (engine.player+1)%2;
		engine.legalMove(engine.player);
		if (!engine.isPossibleMove()) {
			engine.player = (engine.player+1)%2;
			engine.legalMove(engine.player);
			winner = updateEnd(!engine.isPossibleMove(),engine,winner);
		}
		winner = updateEnd(false,engine,winner);
		loc.remove(0);  loc.remove(0);
		return winner;
	}
	
	/*****************************************************************************************
	 * JEU MIN-MAX
	 *****************************************************************************************/

	public ArrayList<Engine> getChild(Engine parentEngine, int playerColor){
		//gives a list of the childEngine (corresponding to a possible move from the parentEngine) of the parentEngine
		ArrayList<Engine> child = new ArrayList<Engine>();
		ArrayList<int[]> possibleLocation = parentEngine.getPossibleMoves();

		for (int[] locTest : possibleLocation) {
			Engine engineChild = (Engine) parentEngine.clone();
			engineChild.addDisk(new Coordinate(locTest[0],locTest[1]), playerColor);
			engineChild.resetLegalMoves();
			engineChild.player = (playerColor+1)%2;
			engineChild.legalMove(playerColor);
			if (!engineChild.isPossibleMove()) {
				engineChild.player = (playerColor+1)%2;
				engineChild.legalMove(playerColor);
			}
			child.add(engineChild);
		}
		
		return child;
	}
	
	public int minMax(Engine gameConfig, int depth, int player) {
		//min max algorithm
		if (!gameConfig.isPossibleMove() || depth <= 0 ) {
			return gameConfig.score()[this.playerColor];
		}
		else if (this.playerColor == player) {
			ArrayList<Engine> childNode = getChild(gameConfig,player);
			int value = Integer.MIN_VALUE;
			for (Engine engineChild : childNode) {
				if (this.timeInGame >= this.timeLimite) {
					break;
				}
				value = (Integer) Math.max(value,minMax(engineChild, depth-1 ,engineChild.player));
			}
			return value;
		}
		else {
			ArrayList<Engine> childNode = getChild(gameConfig,player);
			int value = Integer.MAX_VALUE;
			for (Engine engineChild : childNode) {
				if (this.timeInGame >= this.timeLimite) {
					break;
				}
				value = (Integer) Math.min(value,minMax(engineChild, depth-1 ,engineChild.player));
			}
			return value;
		}
	}
	
	public void nextMinMaxStep(int depth) {
		//implementation of the min max algorithm with the heuristic 1
		Engine engineOriginal = (Engine) engine.clone();
		ArrayList<Engine> childNode = getChild(engineOriginal,this.playerColor);
		ArrayList<int[]> possibleLocation = engineOriginal.getPossibleMoves();
		
		int indexMax = 0;
		int valueMax = Integer.MIN_VALUE;
		for (int i = 0; i < childNode.size(); i++) {
			if (this.timeInGame >= this.timeLimite) {
				System.out.println("Temps �coul� !!");
				break;
			}
			Engine childEngine = childNode.get(i);
			int valueNew = this.minMax(childEngine, depth , (this.playerColor+1)%2);
			//heuristic 1: we only consider the score (ie. sum of player color's Disk on the board)
			if (valueNew > valueMax) {
				indexMax = i;
				valueMax = valueNew;
			}
		}
		if (childNode.size()>0) {
			loc.add(possibleLocation.get(indexMax)[0]); loc.add(possibleLocation.get(indexMax)[1]);
		}
	}
	
	public void nextMinMaxOptiStep(int depth) {
		//implementation of the min max algorithm with the heuristic 2
		Engine engineOriginal = (Engine) engine.clone();
		ArrayList<Engine> childNode = getChild(engineOriginal,this.playerColor);
		ArrayList<int[]> possibleLocation = engineOriginal.getPossibleMoves();
		
		int indexMax = 0;
		int valueMax = Integer.MIN_VALUE;
		for (int i = 0; i < childNode.size(); i++) {
			if (this.timeInGame >= this.timeLimite) {
				System.out.println("Temps �coul� !!");
				break;
			}
			Engine childEngine = childNode.get(i);
			int valueNew = this.minMax(childEngine, depth , (this.playerColor+1)%2);
			//heuristic 2: we consider the score (ie. sum of player color's Disk on the board) AND the location (ie. being on the edge of the board is better)
			if (possibleLocation.get(i)[0]==0 || possibleLocation.get(i)[0]==this.getHeight()-1) {
				valueNew=valueNew*2;
			}
			if (possibleLocation.get(i)[1]==0 || possibleLocation.get(i)[1]==this.getWidth()-1) {
				valueNew=valueNew*2;
			}
			if (valueNew > valueMax) {
				indexMax = i;
				valueMax = valueNew;
			}
		}
		if (childNode.size()>0) {
			loc.add(possibleLocation.get(indexMax)[0]); loc.add(possibleLocation.get(indexMax)[1]);
		}
	}
	
	/*****************************************************************************************
	 * TOUR DE JEU
	 *****************************************************************************************/
	
	public int minMax_AlphaBeta(Engine gameConfig, int depth, int player, int alpha, int beta) {
		if (!gameConfig.isPossibleMove() || depth <= 0) {
			return gameConfig.score()[this.playerColor];
		}
		else if (this.playerColor == player) {
			ArrayList<Engine> childNode = getChild(gameConfig,player);
			int value = Integer.MIN_VALUE;
			for (Engine engineChild : childNode) {
				if (this.timeInGame >= this.timeLimite) {
					break;
				}
				int eval = minMax_AlphaBeta(engineChild, depth-1 , engineChild.player, alpha, beta);
				value = (Integer) Math.max(value,eval);
				alpha = Math.max(alpha, eval);
				if (beta <= alpha ) {
					break;
				}
			}
			return value;
		}
		else {
			ArrayList<Engine> childNode = getChild(gameConfig,player);
			int value = Integer.MAX_VALUE;
			for (Engine engineChild : childNode) {
				if (this.timeInGame >= this.timeLimite) {
					break;
				}
				int eval = minMax_AlphaBeta(engineChild, depth-1 , engineChild.player, alpha, beta);
				value = (Integer) Math.min(value,eval);
				beta = Math.min(beta, eval);
				if (beta <= alpha ) {
					break;
				}
			}
			return value;
		}
	}
	
	public void nextMinMaxStep_AlphaBeta(int depth) {
		Engine engineOriginal = (Engine) engine.clone();
		ArrayList<Engine> childNode = getChild(engineOriginal,this.playerColor);
		ArrayList<int[]> possibleLocation = engineOriginal.getPossibleMoves();
		
		int indexMax = 0;
		int valueMax = Integer.MIN_VALUE;
		for (int i = 0; i < childNode.size(); i++) {
			if (this.timeInGame >= this.timeLimite) {
				System.out.println("Temps �coul� !!");
				break;
			}
			Engine childEngine = childNode.get(i);
			int valueNew = this.minMax_AlphaBeta(childEngine, depth , (this.playerColor+1)%2, Integer.MIN_VALUE, Integer.MAX_VALUE);
			if (valueNew > valueMax) {
				indexMax = i;
				valueMax = valueNew;
			}
		}
		if (childNode.size()>0) {
			loc.add(possibleLocation.get(indexMax)[0]); loc.add(possibleLocation.get(indexMax)[1]);
		}
	}
	
	public void nextMinMaxOptiStep_AlphaBeta(int depth) {
		Engine engineOriginal = (Engine) engine.clone();
		ArrayList<Engine> childNode = getChild(engineOriginal,this.playerColor);
		ArrayList<int[]> possibleLocation = engineOriginal.getPossibleMoves();
		
		int indexMax = 0;
		int valueMax = Integer.MIN_VALUE;
		for (int i = 0; i < childNode.size(); i++) {
			if (this.timeInGame >= this.timeLimite) {
				System.out.println("Temps �coul� !!");
				break;
			}
			Engine childEngine = childNode.get(i);
			int valueNew = this.minMax(childEngine, depth , (this.playerColor+1)%2);
			if (possibleLocation.get(i)[0]==0 || possibleLocation.get(i)[0]==this.getHeight()-1) {
				valueNew=valueNew*2;
			}
			if (possibleLocation.get(i)[1]==0 || possibleLocation.get(i)[1]==this.getWidth()-1) {
				valueNew=valueNew*2;
			}
			if (valueNew > valueMax) {
				indexMax = i;
				valueMax = valueNew;
			}
		}
		if (childNode.size()>0) {
			loc.add(possibleLocation.get(indexMax)[0]); loc.add(possibleLocation.get(indexMax)[1]);
		}
	}
	
	/*****************************************************************************************
	 * TOUR DE JEU
	 *****************************************************************************************/
	
	public void nextStep() {
		//it tell what algorithm is going to be played
		if (this.mode[this.playerColor]==0) {
			this.nextHumainStep();
		}
		else {
			if (this.mode[this.playerColor]==1) {
				this.randomStep();
			}
			else if (this.mode[this.playerColor]==2) {
				this.nextMonteCarloStep(20);
			}
			else if (this.mode[this.playerColor]==3) {
				this.nextMinMaxStep(3);
			}
			else if (this.mode[this.playerColor]==4) {
				this.nextMinMaxOptiStep(2);
			}
			else if (this.mode[this.playerColor]==5) {
				this.nextMinMaxStep_AlphaBeta(3);
			}
			else if (this.mode[this.playerColor]==6) {
				this.nextMinMaxOptiStep_AlphaBeta(3);
			}
			this.nextHumainStep();
		}
	}
	
	public void nextHumainStep() {
		this.engine.addDisk(new Coordinate(loc.get(0),loc.get(1)), this.playerColor);
		this.engine.resetLegalMoves();
		this.playerColor = (this.playerColor+1)%2;
		this.engine.legalMove(this.playerColor);
		if (!this.engine.isPossibleMove()) {
			if (this.gameTest ==0) {
				this.engine.toString();
			}
			this.playerColor = (this.playerColor+1)%2;
			this.engine.legalMove(this.playerColor);
			this.updateEnd(!this.engine.isPossibleMove());
		}
		this.updateEnd(false);
		loc.remove(0);  loc.remove(0);
	}
	
	public void updateEnd(boolean forced) {
		//updates the situation of the game. If it is over then it updates the winner to 0 (blacks win), 1 (whites win) or 2 (it's a tie).
		if ((this.engine.isFullBoard() || forced)) {
			if (this.engine.score()[0] > this.engine.score()[1]) {
				this.winner = 0;
			}
			else if (this.engine.score()[0] < this.engine.score()[1]) {
				this.winner = 1;
			}
			else {
				this.winner = 2;
			}
		}
	}
	
	public int updateEnd(boolean forced, Engine engine, int winner) {
		if ((engine.isFullBoard() || forced)) {
			if (engine.score()[0] > engine.score()[1]) {
				winner = 0;
			}
			else if (engine.score()[0] < engine.score()[1]) {
				winner = 1;
			}
			else {
				winner = 2;
			}
		}
		return winner;
	}
}
