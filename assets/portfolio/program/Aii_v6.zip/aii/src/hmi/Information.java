package hmi;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JPanel;

import control.GameController;

public class Information extends JPanel{
	private static final long serialVersionUID = 1L;
	private GameController gameController;
	private int gameState;

	public Information(GameController controle, int gameState) {
		this.gameController = controle;
		this.gameState = gameState;
	}
	
	public void paint(Graphics graphics) {
		int plateau = this.getWidth()-10;
		int margePlateauX = 5;
		int margePlateauY = 5;
		
		if (gameState==0) {
			graphics.setColor(Color.darkGray);
			graphics.fillRect(margePlateauX, margePlateauY, plateau, 80);
			graphics.setColor(Color.WHITE);
			graphics.setFont(graphics.getFont().deriveFont(Font.BOLD, 40.0f));
			graphics.drawString("REVERSI GAME", this.getWidth()/2-140, this.getHeight()/2);
		}
		else if (gameState==1) {
			int pl = this.gameController.playerColor;
			graphics.setColor(Color.darkGray);
			graphics.fillRect(margePlateauX, margePlateauY, plateau, 80);
			graphics.setFont(graphics.getFont().deriveFont(Font.BOLD, 23.0f));
			if (pl == 0) {
				graphics.setColor(Color.RED);
				graphics.drawString("It's dark Disks turn to play", 90, 5*margePlateauY);
			}
			else {
				graphics.setColor(Color.WHITE);
				graphics.drawString("It's white Disks turn to play", 90, 5*margePlateauY);
			}
			graphics.setColor(Color.white);
			graphics.setFont(graphics.getFont().deriveFont(Font.ITALIC, 12.0f));
			int[] score = this.gameController.score();
			graphics.drawString("Black: "+score[0], 20, 12*margePlateauY);
			graphics.drawString("White: "+score[1], this.getWidth()-80, 12*margePlateauY);
			
			graphics.setFont(graphics.getFont().deriveFont(Font.BOLD, 30.0f));
			int time = this.gameController.timeInGame/10;
			if (time >=100) {
				graphics.setColor(Color.red);
				graphics.drawString("Time : " + time/10 +","+ (time - ((int)time/10)*10) +" s", this.getWidth()/2-80, 16*margePlateauY);
			}
			else {
				graphics.setColor(Color.white);
				if (time < 10) {
					graphics.drawString("Time : 00," + time +" s", this.getWidth()/2-80, 16*margePlateauY);
				}
				else if(time <100)
					graphics.drawString("Time : 0" + time/10 +","+ (time - ((int)time/10)*10) +" s", this.getWidth()/2-80, 16*margePlateauY);
 			}
		}
		else if (this.gameState==2) {
			graphics.setColor(Color.darkGray);
			graphics.fillRect(margePlateauX, margePlateauY, plateau, 80);
			graphics.setColor(Color.white);
			graphics.setFont(graphics.getFont().deriveFont(Font.BOLD, 26.0f));
			int[] score = this.gameController.score();
			graphics.drawString("Black: "+score[0], 20, 12*margePlateauY);
			graphics.drawString("White: "+score[1], this.getWidth()-150, 12*margePlateauY);
		}
		
		
//		if (this.gameState == 0) {
//			this.setVisible(false);
//		}
//		else if (this.gameState == 1) {
//			this.setVisible(true);
//		}
	}
	
	public void update(int gameState) {
		this.gameState = gameState;
		this.repaint();
	}
}
