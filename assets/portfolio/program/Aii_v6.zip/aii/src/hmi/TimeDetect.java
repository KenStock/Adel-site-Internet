package hmi;

import java.util.TimerTask;

import control.GameController;

public class TimeDetect extends TimerTask {
	private int time;
	private GameController gameController;
	private Information information;
	
	public TimeDetect(GameController gameController, Information information) {
		this.time = 0;
		this.gameController = gameController;
		this.information = information;
	}
	
	public void run() {
		this.time++;
		this.gameController.timeInGame = this.time;
		this.information.repaint();
	}
}