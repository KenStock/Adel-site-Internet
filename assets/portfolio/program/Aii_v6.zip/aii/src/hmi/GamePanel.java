package hmi;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import control.GameController;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class GamePanel extends JPanel{

	private GameController gameController;
	private int h ;
	private int w;
	public Box[][] table;
	int gameState = 0;
	JPanel tab = new JPanel();
	

	public GamePanel(GameController controle) {
		this.gameController = controle;
		this.h = this.gameController.getHeight();
		this.w = this.gameController.getWidth();
		this.table = new Box[h][w];
	}
	
	public void setTable(JPanel tab, Box[][] table) {
		this.tab = tab;
		this.table = table;
	}

	public void paint(Graphics graphics) {
		if (this.gameState == 0) {
			//displays the start screen
			try {
				Image Im = ImageIO.read(new File("startScreen.png")).getScaledInstance(this.getWidth(), this.getHeight(), Image.SCALE_DEFAULT);
				graphics.drawImage(Im, 0, 0, null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else if (this.gameState == 1) {
			//displays the board of the game
			graphics.setColor(Color.darkGray);
			graphics.fillRect(0,0,this.getWidth(), this.getHeight());
			try {
				Image[] img = {ImageIO.read(new File("blacks.png")),
						               ImageIO.read(new File("whites.png"))};
			
				for (int i = 0; i < h; i++) {
					for (int j = 0; j < w; j++) {
					
						int color = gameController.getCellColor(j, i);
						if (color==0) {
							this.table[i][j].setImage(img[0]);
						}
						else if (color==1) {
							this.table[i][j].setImage(img[1]);
						}
						this.table[i][j].setPoints(this.gameController.getCellPoints(j, i));
						
						this.table[i][j].repaint();
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
			}
			
			this.add(tab, BorderLayout.CENTER);
			
		}
		else if (this.gameState == 2) {
			//displays the end screen
			if (this.gameController.winner == 0) {
				try {
					Image Im = ImageIO.read(new File("blacksWon.png")).getScaledInstance(this.getWidth(), this.getHeight(), Image.SCALE_DEFAULT);
					graphics.drawImage(Im, 0, 0, null);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				try {
					Image Im = ImageIO.read(new File("whitesWon.png")).getScaledInstance(this.getWidth(), this.getHeight(), Image.SCALE_DEFAULT);
					graphics.drawImage(Im, 0, 0, null);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
				

	public void update(int gameState) {
		this.gameState = gameState;
		this.update(this.getGraphics());
	}
}
