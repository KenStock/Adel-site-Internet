package hmi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

class BouttonListener implements ActionListener{
	int i;
	int j;
	GameWindow gameWindow;
	
	public BouttonListener(int i, int j, GameWindow gameWindow) {
		this.i = i;
		this.j = j;
		this.gameWindow = gameWindow;
	}	
	
	public void actionPerformed(ActionEvent arg0) {
		List<Integer> loc = gameWindow.getLoc();
		if (loc.size() >= 2) {
			loc.remove(0);
			loc.remove(0);
		}
		loc.add(i);
		loc.add(j);
		
		do {
			gameWindow.nextInGameStep();
		} while(gameWindow.getMode()[gameWindow.getPlayerColor()]!=0);
	}
}