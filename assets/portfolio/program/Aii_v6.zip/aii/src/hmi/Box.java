package hmi;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;

public class Box extends JButton {
	
	private Image img;
	public int points;
	
	public Box() {
	    try {
	        img = ImageIO.read(new File("empty.png"));
	      } catch (IOException e) {
	        e.printStackTrace();
	      }
	}
	
	public void setPoints(int points) {
		this.points = points;
		if (points != 0) {
	    	this.setText(""+points);
	    	this.setEnabled(true);
	    }
	    else {
	    	this.setEnabled(false);
	    }
	}
	
	public void paintComponent(Graphics g){
//		Graphics2D g2d = (Graphics2D)g;
		g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);
		if (points != 0) {
			g.setColor(Color.RED);
			g.drawString(""+this.points, this.getWidth()/2-3, this.getHeight()/2+3);
		}
		else {
			g.drawString("", 0, 0);
		}
	}
	
	public void setImage(Image img) {
		this.img = img;
	}
}
