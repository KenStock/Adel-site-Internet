package hmi;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Timer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import control.GameController;

public class GameWindow extends JFrame {
	
	private GamePanel gamePanel;
	private GameController gameController;
	private JButton button;
	private JPanel tab = new JPanel();
	public Box[][] table;
	private int h ;
	private int w;
	int gameState;
	private Information information;
	int[] mode;
	
	public GameWindow(GamePanel gameP, GameController gameC, Information info) {
		this.setTitle("Reversi game");
		this.setSize(new Dimension(480, 600));
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setLocationRelativeTo(null);
		this.setResizable(true);
		
		this.h = gameC.getHeight();
		this.w = gameC.getWidth();
		
		this.gameState = 0;
		this.gamePanel = gameP;
		this.gameController = gameC;
		
		//information contains all the in game informations (the score, the player who have to play...)
		this.information = info;
		this.information.setPreferredSize(new Dimension(480,120));
		this.getContentPane().add(this.information, BorderLayout.NORTH);
		
		//the button is used to get to a new game state
		this.button = new JButton("Jouer");
		this.button.addActionListener(new ButtonStart());
		this.getContentPane().add(this.button, BorderLayout.PAGE_END);
		
		//the gamPanel displays the board which is contained into the Object "table"
		this.gamePanel.setDoubleBuffered(true);
		this.gamePanel.setPreferredSize(new Dimension(480, 480));
		this.getContentPane().add(this.gamePanel, BorderLayout.CENTER);
		
		this.table = new Box[h][w];
		tab.setBackground(Color.darkGray);
	    tab.setLayout(new GridLayout(h, w, 5, 5));
	    //Adding buttons to the table
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				Box but = new Box();
				but.setPreferredSize(new Dimension(55, 55));
				but.addActionListener(new BouttonListener(i,j,this));
				this.table[j][i] = but;
				tab.add(but);
			}
		}
		this.gamePanel.setTable(tab,table);
		
		this.pack();
		this.setVisible(true);
		
		//if players are auto, they directly start to play
		if (gameController.mode[0]!=0) {
			if (gameController.mode[1]!=0) {
				this.gameState++;
				fonctionnement(gameState);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			do {
				this.nextInGameStep();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} while(gameController.mode[gameController.playerColor]!=0 && gameController.winner==-1);
		}
		
	}
	
	public void fonctionnement(int gameState) {
		//used to shape the window given the gameState
		this.gameState = gameState;
		if(this.gameState == 0) {
			this.getContentPane().remove(this.button);
			this.button = new JButton("Rejouer ?");
			this.button.addActionListener(new ButtonStart());
			this.getContentPane().add(this.button, BorderLayout.PAGE_END);
		}
		else if(this.gameState == 1) {
			this.getContentPane().remove(this.button);
			this.gamePanel.update(this.gameState);
			this.information.update(this.gameState);
			
		}
		else if(this.gameState == 2) {
			this.getContentPane().remove(this.button);
			this.button = new JButton("Next");
			this.button.addActionListener(new ButtonNext());
			this.getContentPane().add(this.button, BorderLayout.PAGE_END);
		}
		this.pack();
		this.setVisible(true);
	}
	
	public void nextInGameStep() {
		if (this.gameController.gameTest == 0) {
			//timer is set around the nextStep function of the gameController
			Timer gameTimer = new Timer(true);
			for(int i = 1; i<=100 ; i++) {
				gameTimer.scheduleAtFixedRate(new TimeDetect(this.gameController, this.information),0,10);
			}
			this.gameController.nextStep();
			gameTimer.cancel();
			this.gameController.timeInGame = 0;
			
			this.information.repaint();
			this.gamePanel.repaint();
			if (this.gameController.winner != -1) {
				//detects if the state of the gae have changed
				this.fonctionnement((this.gameState+1)%3);
			}
			this.pack();
		}
	}

	public List<Integer> getLoc(){
		return this.gameController.loc;
	}
	
	public int getPlayerColor() {
		return this.gameController.playerColor;
	}
	
	public int[] getMode() {
		return this.gameController.mode;
	}
		
		
	public class ButtonNext implements ActionListener{
		//this class implements the next button listener
		public void actionPerformed(ActionEvent arg0) {
			gamePanel.update(gameState);
			information.update(gameState);
		}
	}
		
		
		
		public class ButtonStart implements ActionListener{
			//this class implements the start button listener
			public void actionPerformed(ActionEvent arg0) {
				gameState = (gameState+1)%3;
				fonctionnement(gameState);
			}
		}
		
		
}

