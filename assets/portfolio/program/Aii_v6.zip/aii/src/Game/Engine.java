package Game;

import java.util.ArrayList;

public class Engine {
	
	/*
	 * height = height of the board
	 * width = width of the board
	 * board = table of Cell table corresponding to the board game
	 * 
	 * player : player curently playing;  0 = black; 1 = whites
	 */
	
	public int height = 8;
	public int width = 8;
	public Cell[][] board;
	
	public int player;
	
	
	public Engine() {
		this.board = new Cell[height][width];
		//initialization of the board
		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
				board[i][j] = new Cell(-1);
			}
		}
		this.board[this.width/2 - 1][this.height/2 - 1].changeColor(1);;
		this.board[this.width/2][this.height/2].changeColor(1);
		this.board[this.width/2 - 1][this.height/2].changeColor(0);
		this.board[this.width/2][this.height/2 - 1].changeColor(0);
		this.legalMove(0);
	}
	
	public Cell getCell(Coordinate coordinate) {
		return this.board[coordinate.y][coordinate.getIntX()];
	}
	
	public Cell getCell(int x, int y) {
		return this.board[y][x];
	}
	
	public int getHeight() {
		return this.height;
	}
	
	public int getWidth() {
		return this.width;
	}
	
	public int getCellColor(int x, int y) {
		return this.getCell(x,y).getColor();
	}
	
	public int getCellPoints(int x, int y) {
		return this.getCell(x,y).getPoints();
	}
	
	//toString allow us to print in asci grid our board.
	public String toString() {
		String str = "";
		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
//				if (this.getCell(new Coordinate(i, j)).getPoints() != 0) {
					str += "\t"+ this.getCell(new Coordinate(i, j)).getPoints();
//				}
//				else {
//					str += "\t"+ this.getCellColor(i, j);
//				}
			}
			str+="\n";
		}
		return str;
	}
	
	//clone() allow us to make a deep copy of the curent engine
	@Override
	public Object clone() {
		Engine engine = null;
		try {
			engine = (Engine) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			engine = new Engine();
			for (int i = 0; i < this.height; i++) {
				for (int j = 0; j < this.width; j++) {
					engine.board[i][j] = (Cell) this.board[i][j].clone();
				}
			}
		}
		return engine;
	}
	
	/***********************************************************************************************
	 * LEGAL MOVES
	 ***********************************************************************************************/
	
	//Gives the list of possible empty neighbours of the cell coordinate (x,y)
	public ArrayList<Coordinate> getNeighbours(int x , int y) {
		ArrayList<Coordinate> neighbours = new ArrayList<Coordinate>();
		for (int j = -1; j <= 1 ; j++) {
			for (int i = -1; i <= 1 ; i++ ) {
				if ((x + i< this.width && x + i>=0 && y + j< this.height && y + j>=0) && this.getCell(x + i, y + j).isEmptyColor()) {
					neighbours.add(new Coordinate(x +i, y +j));
				}
			}
		}
		return neighbours;
	}
	
	//looks for color of the current player on the direction expectedC coordinate to onBoardC coordinate.
	public void isThereSameColor(Coordinate onBoardC, Coordinate expectedC) {
		int playerColor = (this.getCell(onBoardC).getColor()+1) % 2;
		int points = 1;
		
		Coordinate vector = new Coordinate(onBoardC.getIntX() - expectedC.getIntX(), onBoardC.y - expectedC.y); //direction of analysis
		Coordinate testedC = new Coordinate( onBoardC.getIntX() + vector.getIntX() , onBoardC.y + vector.y);
		ArrayList<Coordinate> futurFlipC = new ArrayList<Coordinate>();
		futurFlipC.add(onBoardC);
		boolean ok = true;
		
		while( (testedC.getIntX() >= 0 && testedC.getIntX() < this.width) && (testedC.y >= 0 && testedC.y < this.height) && ok ) { //while there is some thing to explore
			if (this.getCell(testedC).getColor() == playerColor) { //the cell color is the same as the current player --> stop searching + modify the cell
				this.getCell(expectedC).addCellsTwist(futurFlipC, points);
				ok = false;
			}
			else if (this.getCell(testedC).getColor() == (playerColor+1) %2) { //the cell color is opposed to the current player --> keep searching
				futurFlipC.add(new Coordinate(testedC.x,testedC.y));
				testedC.add(vector);
				points++;
			}
			else { //the cell color is empty --> stop searching
				ok = false;
			}	
		}	
	}
	
	//updates every legal moves of the board given the player color
	public void legalMove(int playerColor) {
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				if (this.getCell(i,j).getColor() == (playerColor +1) % 2 ) {
					ArrayList<Coordinate> neighbours = this.getNeighbours(i,j);
					for (Coordinate n : neighbours) {
						this.isThereSameColor(new Coordinate(i,j), n);
					}
				}
			}
		}
	}
	
	public void resetLegalMoves() {
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				this.getCell(i,j).resteCellsTwist();
			}
		}
	}
	
	/***********************************************************************************************
	 * BOARD MOVES
	 ***********************************************************************************************/
	
	public void addDisk(Coordinate newCoordinate, int playerColor) {
		Cell newCell = this.getCell(newCoordinate);
		if (!newCell.isEmpty()){
			newCell.changeColor(playerColor);
			ArrayList<Coordinate> cellsTwist = newCell.getCellsTwist();
			for (Coordinate twistedC : cellsTwist) {
				this.getCell(twistedC).changeColor(playerColor);
			}
		}
	}
	
	//are there some empty cells left ?
	public boolean isFullBoard() {
		boolean full = true;
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				if (this.getCell(i,j).isEmptyColor()) {
					full = false;
				}
			}
		}
		return(full);
	}
	
	//are there any possible move ?
	public boolean isPossibleMove() {
		boolean possible = false;
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				if (!this.getCell(i,j).isEmpty()) {
					possible = true;
				}
			}
		}
		return(possible);
	}
	
	public int[] score() {
		int[] score = {0,0};
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				if (this.getCellColor(i, j) ==0) {
					score[0]++;
				}
				else if (this.getCellColor(i, j) == 1) {
					score[1]++;
				}
			}
		}
		return score;
	}
	
	public ArrayList<int[]> getPossibleMoves(){
		ArrayList<int[]> possibleMoves = new ArrayList<int[]>();
		for (int j = 0 ; j < this.height ; j++ ) {
			for (int i = 0 ; i < this.width ; i++ ) {
				if (!getCell(i, j).isEmpty()) {
					int[] intCoordinate = {i,j};
					possibleMoves.add(intCoordinate);
				}
			}
		}
		return possibleMoves;
	}
}