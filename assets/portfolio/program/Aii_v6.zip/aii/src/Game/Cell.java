package Game;

import java.util.ArrayList;

public class Cell {
	
	/*
	 * color : the color of the cell
	 * 		> -1 = it's empty
	 * 		> 0 = it's dark
	 * 		> 1 = it's white
	 * 
	 * cellsTwist: contains all the cell's coordinate that might be twisted if we play in this location
	 * 
	 * points : the points we are going to win if we play here
	 */

	private int color;
	private ArrayList<Coordinate> cellsTwist = new ArrayList<Coordinate>();
	public int points = 0;
	
	public Cell(int color) {
		this.color = color;
	}
	
	//Clone allow us to make a deep copy of our cells
	@Override
	public Object clone() {
		try {
			return (Cell) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			Cell cell = new Cell(this.color);
			for (Coordinate coord : this.cellsTwist) {
				cell.cellsTwist.add((Coordinate) coord.clone());
			}
			return cell;
		}
	}
	
	protected int getPoints() {
		return this.points;
	}
	
	/***********************************************************************************************
	 * RELATIVE TO THE COLOR
	 ***********************************************************************************************/
	
	
	protected int getColor() {
		return this.color;
	}
	
	protected void changeColor(int color) {
		this.color = color;
	}
	
	protected boolean isEmptyColor() {
		return(this.color == -1);
	}
	
	/***********************************************************************************************
	 * RELATIVE TO THE POSSIBLE TWISTING CELLS
	 ***********************************************************************************************/
	
	
	protected ArrayList<Coordinate> getCellsTwist() {
		return this.cellsTwist;
	}
	
	protected void addCellsTwist(ArrayList<Coordinate> listCoordinate, int points) {
		this.cellsTwist.addAll(listCoordinate);
		this.points += points;
	}
	
	protected void resteCellsTwist() {
		this.cellsTwist.clear();
		this.points = 0;
	}
	
	//isEmpty tells you if there is any move you can make onto this cell.
	protected boolean isEmpty() {
		return this.cellsTwist.isEmpty();
	}
}
	