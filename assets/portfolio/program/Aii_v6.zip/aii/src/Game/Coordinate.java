package Game;

public class Coordinate {
	char x;
	int y;
	
	/*
	 * x : the x coordinate (in character)
	 * y : the y coordinate (in number)
	 */
	
	public Coordinate(char x, int y) {
		this.x = x;
		this.y = y;
	}
	
	//Clone allow us to make a deep copy of our coordinate
	public Object clone() {
		try {
			return (Coordinate) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			Coordinate coordinate = new Coordinate(this.x,this.y);
			return coordinate;
		}
	}
	
	public Coordinate(int x, int y) {
		this.toCoordinate(x, y);
	}
	
	public int[] toInteger() {
		int[] coordinate = {((int) this.x) - ((int) 'a'),y};
		return coordinate;
	}
	
	public void toCoordinate(int x, int y) {
		this.x = (char) ( ((int) 'a') + x);
		this.y = y;
	}
	
	public int getIntX() {
		return ((int) this.x) - ((int) 'a');
	}
	
	//add: sum up 2 Coordinates like this (a,2).add( (b,9) ) = (c,11)
	public void add(Coordinate coordinate) {
		this.x = (char) (((int) this.getIntX() + (int) coordinate.x));
		this.y = this.y + coordinate.y;
	}
}
